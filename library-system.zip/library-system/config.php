<?php
$conn = mysqli_connect("localhost","root","","library_system") or die("Connection Failed : " . mysqli_connect_error());

$base_url = "Location: http://localhost/library-system";

$limit = 5; 
?>
