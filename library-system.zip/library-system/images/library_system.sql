-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 29, 2021 at 06:32 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `username`, `password`) VALUES
(1, 'Dhaka College', 'administrator', '95faf1557da95f67f530b5f224294806');

-- --------------------------------------------------------

--
-- Table structure for table `author`
--

CREATE TABLE `author` (
  `author_id` int(11) NOT NULL,
  `author_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `author`
--

INSERT INTO `author` (`author_id`, `author_name`) VALUES
(2, 'Humayun Ahmed'),
(3, 'Jafor Iqbal'),
(5, 'Jashimuddin'),
(6, 'Rabindranath Tagore'),
(19, 'Kazi Nazrul Islam'),
(20, 'Doctor Robertson');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `book_id` int(11) NOT NULL,
  `book_name` varchar(50) NOT NULL,
  `book_category` varchar(30) NOT NULL,
  `book_author` varchar(50) NOT NULL,
  `book_publisher` varchar(40) NOT NULL,
  `book_status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`book_id`, `book_name`, `book_category`, `book_author`, `book_publisher`, `book_status`) VALUES
(11, 'Boo And Zoo', '4', '20', '2', 'N'),
(12, 'Computer The Machine', '2', '20', '5', 'Y'),
(13, 'Masud Rana', '3', '2', '7', 'N'),
(14, 'Ami Topu', '4', '3', '1', 'Y'),
(15, 'Kobor', '12', '5', '13', 'N'),
(16, 'Holud Himu Kalo RAB', '7', '2', '4', 'N'),
(17, 'Chol Chol Chol', '12', '3', '1', 'N');

-- --------------------------------------------------------

--
-- Table structure for table `book_issue`
--

CREATE TABLE `book_issue` (
  `issue_id` int(11) NOT NULL,
  `issue_name` varchar(50) NOT NULL,
  `issue_book` varchar(40) NOT NULL,
  `issue_date` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `issue_status` varchar(10) NOT NULL,
  `return_day` date DEFAULT NULL,
  `fine` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book_issue`
--

INSERT INTO `book_issue` (`issue_id`, `issue_name`, `issue_book`, `issue_date`, `return_date`, `issue_status`, `return_day`, `fine`) VALUES
(41, '5', '12', '2021-10-27', '2021-11-11', 'Y', '2021-11-23', NULL),
(42, '1', '14', '2021-10-27', '2021-11-11', 'Y', '2021-10-27', NULL),
(43, '2', '14', '2021-11-17', '2021-12-02', 'Y', '2021-11-23', NULL),
(44, '3', '12', '2021-11-23', '2021-11-25', 'N', NULL, NULL),
(45, '3', '17', '2021-11-23', '2021-12-08', 'N', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`category_id`, `category_name`) VALUES
(2, 'Historical Fiction.'),
(3, 'Detective and Mystery'),
(4, 'Literary Fiction'),
(7, 'Comic Book or Graphic Novel'),
(10, 'Horror'),
(12, 'Poem');

-- --------------------------------------------------------

--
-- Table structure for table `publisher`
--

CREATE TABLE `publisher` (
  `publisher_id` int(11) NOT NULL,
  `publisher_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `publisher`
--

INSERT INTO `publisher` (`publisher_id`, `publisher_name`) VALUES
(1, 'Adorn Publication'),
(2, 'Anannya Publisher'),
(4, 'Shomoy Prokashon'),
(5, 'Mowla Brothers'),
(7, 'Gatidhaka'),
(8, 'Kakoli Prokashoni'),
(13, 'Dribbo Prokash');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `return_days` int(11) NOT NULL,
  `fine` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `return_days`, `fine`) VALUES
(1, 15, 20);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `student_name` varchar(50) NOT NULL,
  `student_address` varchar(100) NOT NULL,
  `student_gender` varchar(10) NOT NULL,
  `student_class` varchar(30) NOT NULL,
  `student_age` int(11) NOT NULL,
  `student_phone` varchar(12) NOT NULL,
  `student_email` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_name`, `student_address`, `student_gender`, `student_class`, `student_age`, `student_phone`, `student_email`) VALUES
(1, 'Miraz Ahmed', 'Kallayanpur, Mirpur Road, Dhaka', 'male', 'BBA 1st', 20, '01746120516', 'miraz231@dhakacollege.com'),
(2, 'Rafi Dewan', 'Gulistan, Dhaka', 'male', 'English 3rd', 23, '01865151555', 'rafi462@@dhakacollege.com'),
(3, 'Supriyo Mim', 'Lake Circus, Dhanmoni, Dhaka', 'female', 'Bangla 2nd', 22, '01756987441', 'min3735@dhakacollege.com'),
(5, 'Nafisa Islam', '', 'female', 'English 1st', 20, '01855244553', 'nafisa74@dhakacollege.com'),
(6, 'Kanta Moni', 'Gulshan 2, Dhaka', 'female', 'Bangla 4th', 24, '01936523434', 'kanta78@dhakacollege.com'),
(7, 'Jahid Shanto', 'Savar, Dhaka 1350', 'male', 'BCOM 4th', 26, '01800000001', 'jahid@dhakacollege.com'),
(8, 'Nahid Bhuiyan', 'Nikunjo Dhaka', 'male', 'Social Science 3rd', 21, '01904615532', 'nahid1@dhakacollege.com'),
(17, 'Ahnaf Khan', 'B Baria Bangladesh', 'male', 'Social Science 3rd Year', 21, '014505656666', 'ahnaf@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `author`
--
ALTER TABLE `author`
  ADD PRIMARY KEY (`author_id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`book_id`);

--
-- Indexes for table `book_issue`
--
ALTER TABLE `book_issue`
  ADD PRIMARY KEY (`issue_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `publisher`
--
ALTER TABLE `publisher`
  ADD PRIMARY KEY (`publisher_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `author`
--
ALTER TABLE `author`
  MODIFY `author_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `book`
--
ALTER TABLE `book`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `book_issue`
--
ALTER TABLE `book_issue`
  MODIFY `issue_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `publisher`
--
ALTER TABLE `publisher`
  MODIFY `publisher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
